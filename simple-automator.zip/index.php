<?php
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
//Non c'è niente da vedere qua