<?php
/**
 * Plugin Name: Simple Automator
 * Description: Simple Automator with ChatGPT and DALL-E Integration
 * Author: Trizeta
 * Author URI: https://www.sys-datgroup.com/trizeta/
 * Version: 1.3.0
 * Text Domain: simple-automator
 */

// Impedisce l'accesso diretto al file
if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

// Includi i file necessari di WordPress per la gestione dei media
require_once(ABSPATH . 'wp-admin/includes/media.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/image.php');

// Definizione della classe principale del plugin
class SimpleAutomator {
    // Proprietà private per memorizzare le impostazioni del plugin
    private $api_key;
    private $temperature;
    private $max_tokens;

    // Costruttore della classe
    public function __construct() {
        // Aggiunge azioni per caricare asset, shortcode e script
        add_action('wp_enqueue_scripts', array($this, 'load_assets'));
        add_shortcode('contact-form', array($this, 'load_shortcode'));
        add_action('wp_footer', array($this, 'load_scripts'));
        // Registra le API REST
        add_action('rest_api_init', array($this, 'register_rest_api'));
        // Aggiunge il menu di amministrazione
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Carica le impostazioni
        $this->load_settings();
    }

    // Carica le impostazioni del plugin
    private function load_settings() {
        $this->api_key = get_option('simple_automator_api_key', '');
        $this->temperature = floatval(get_option('simple_automator_temperature', 0.8));
        $this->max_tokens = intval(get_option('simple_automator_max_tokens', 1024));
    }

    // Aggiunge la pagina delle impostazioni al menu di amministrazione
    public function add_admin_menu() {
        add_options_page('Simple Automator Settings', 'Simple Automator', 'manage_options', 'simple-automator-settings', array($this, 'settings_page'));
    }

    // Renderizza la pagina delle impostazioni
    public function settings_page() {
        // Gestisce il salvataggio delle impostazioni
        if (isset($_POST['simple_automator_save_settings'])) {
            $this->api_key = sanitize_text_field($_POST['simple_automator_api_key']);
            $this->temperature = floatval($_POST['simple_automator_temperature']);
            $this->max_tokens = intval($_POST['simple_automator_max_tokens']);
            
            update_option('simple_automator_api_key', $this->api_key);
            update_option('simple_automator_temperature', $this->temperature);
            update_option('simple_automator_max_tokens', $this->max_tokens);
            
            echo '<div class="updated"><p>Impostazioni salvate con successo!</p></div>';
        }
        
        // Renderizza il form delle impostazioni
        ?>
        <div class="wrap">
            <h1>Impostazioni Simple Automator</h1>
            <form method="post" action="">
                <table class="form-table">
                    <tr>
                        <th><label for="simple_automator_api_key">API Key</label></th>
                        <td><input type="text" id="simple_automator_api_key" name="simple_automator_api_key" value="<?php echo esc_attr($this->api_key); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="simple_automator_temperature">Temperatura</label></th>
                        <td><input type="number" id="simple_automator_temperature" name="simple_automator_temperature" value="<?php echo esc_attr($this->temperature); ?>" step="0.1" min="0" max="1" class="small-text"></td>
                    </tr>
                    <tr>
                        <th><label for="simple_automator_max_tokens">Max Token</label></th>
                        <td><input type="number" id="simple_automator_max_tokens" name="simple_automator_max_tokens" value="<?php echo esc_attr($this->max_tokens); ?>" class="small-text"></td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="simple_automator_save_settings" class="button-primary" value="Salva Modifiche">
                </p>
            </form>
        </div>
        <?php
    }

    // Carica gli asset CSS e JS del plugin
    public function load_assets() {
        $css_file = plugin_dir_path(__FILE__) . 'css/simple-automator.css';
        if (file_exists($css_file)) {
            wp_enqueue_style(
                'simple-automator',
                plugin_dir_url(__FILE__) . 'css/simple-automator.css',
                array(),
                filemtime($css_file),
                'all'
            );
        } else {
            error_log('Simple Automator CSS file not found: ' . $css_file);
        }

        wp_enqueue_script(
            'simple-automator',
            plugin_dir_url(__FILE__) . 'js/simple-automator.js',
            array('jquery'),
            '1.3.0',
            true
        );
    }

    // Carica lo shortcode del form di contatto
    public function load_shortcode() {
    ob_start();
    ?>
    <div class="simple-contact-form">
        <h1>Aggiungi un nuovo articolo <span class="settings-icon" title="Impostazioni">⚙️</span></h1>
        <div id="main-form" <?php echo empty($this->api_key) ? 'style="display: none;"' : ''; ?>>

                <p>Riempi il form sottostante</p>
                <form id="simple-contact-form__form">
                    <div class="form-group mb-2">
                        <input name="titolo" type="text" placeholder="Titolo" class="form-control" required>
                    </div>
                    <div class="form-group mb-2">
                        <textarea name="descrizione" placeholder="Descrizione" class="form-control" required></textarea>
                    </div>
                    <div class="form-group mb-2">
                        <select name="prompt" id="prompt-select" class="form-control">
                            <option value=" ">Prompt di default</option>
                        </select>
                    </div>
                    <br>
                    <div id="new-prompt-container">
                        <div class="form-group mb-2">
                            <input type="text" id="new-prompt" placeholder="Inserisci nuovo prompt" class="form-control">
                            <br><br>
                            <button type="button" id="add-prompt" class="btn btn-primary mt-2">Aggiungi un nuovo prompt</button>
                        </div>
                    </div>
                    <br>
                    <div class="form-group">
                        <center>
                            <button type="button" id="preview-button" class="btn btn-primary btn-block w-100 mr-2">Anteprima</button>
                        </center>
                    </div>
                </form>
                
                <div id="prompt-list-container">
                    <h3>Prompt personalizzati</h3>
                    <ul id="prompt-list"></ul>
                </div>
            </div>
            <br><br>
            <div id="settings-form" style="display: none;">
                <h2>Impostazioni</h2>
                <form id="simple-automator-settings-form">
                    <div class="form-group mb-2">
                        <label for="api_key">API Key:</label>
                        <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr($this->api_key); ?>" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="temperature">Temperature:</label>
                        <input type="number" id="temperature" name="temperature" value="<?php echo esc_attr($this->temperature); ?>" step="0.1" min="0" max="1" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="max_tokens">Max Tokens:</label>
                        <input type="number" id="max_tokens" name="max_tokens" value="<?php echo esc_attr($this->max_tokens); ?>" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Salva modifiche</button>
                    </div>
                </form>
            </div>
        </div>
        <div id="loading-screen" class="loading-screen" style="display: none;">
            <div class="loading-spinner"></div>
            <p>Generazione articolo in corso...</p>
        </div>
        <div id="preview-screen" class="preview-screen" style="display: none;">
            <h2>Anteprima Articolo</h2>
            <h1 id="preview-title"></h1>
            <img id="preview-image" style="max-width: 100%;">
            <textarea id="preview-content" style="width: 100%; height: 300px;"></textarea>
            <button id="save-draft-button">Bozza</button>
            <button id="publish-draft-button">Pubblica Articolo</button>
            <button id="close-preview-button">Chiudi Anteprima</button>
        </div>
        <?php
        return ob_get_clean();
    }

    // Carica gli script JavaScript
    public function load_scripts() {
        ?>
        <script>
            jQuery(document).ready(function($) {
                // Inizializzazione delle variabili
                var apiKey = '<?php echo esc_js($this->api_key); ?>';
                var settingsForm = $('#settings-form');
                var mainForm = $('#main-form');
                var prompts = <?php echo json_encode($this->get_custom_prompts()); ?>;

                // Mostra il form delle impostazioni se l'API key non è impostata
                if (!apiKey) {
                    settingsForm.show();
                    mainForm.hide();
                }

                // Gestisce il click sull'icona delle impostazioni
                $('.settings-icon').click(function() {
                    settingsForm.toggle();
                });
                
                // Gestisce il salvataggio delle impostazioni
                $('#simple-automator-settings-form').on('submit', function(event) {
                    event.preventDefault();
                    var form = $(this).serialize();
                    
                    $.ajax({
                        method: 'POST',
                        url: '<?php echo esc_url_raw(rest_url('simple-automator/v1/save-settings')); ?>',
                        headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                        data: form,
                        success: function(response) {
                            alert('Impostazioni salvate con successo!');
                            settingsForm.hide();
                            mainForm.show();
                        },
                        error: function(xhr, status, error) {
                            alert('Errore: ' + xhr.responseText);
                        }
                    });
                });

                // Gestisce il click sul pulsante per aggiungere un nuovo prompt
                $('#add-new-prompt-btn').click(function() {
                    $('#new-prompt-container').toggle();
                });

                // Gestisce l'aggiunta di un nuovo prompt
                $('#add-prompt').click(function() {
                    var newPrompt = $('#new-prompt').val().trim();
                    if (newPrompt) {
                        prompts.push(newPrompt);
                        $('#prompt-select').append($('<option>', {
                            value: prompts.length - 1,
                            text: newPrompt
                        }));
                        $('#prompt-select').val(prompts.length - 1);
                        $('#new-prompt').val('');
                        updatePromptList();
                        
                        $.ajax({
                            url: '<?php echo esc_url_raw(rest_url('simple-automator/v1/save-prompts')); ?>',
                            method: 'POST',
                            beforeSend: function(xhr) {
                                xhr.setRequestHeader('X-WP-Nonce', '<?php echo wp_create_nonce('wp_rest'); ?>');
                            },
                            data: { prompts: prompts }
                        });
                    }
                });

                // Aggiorna la lista dei prompt
                function updatePromptList() {
                    var promptList = $('#prompt-list');
                    var promptSelect = $('#prompt-select');
                    promptList.empty();
                    promptSelect.find('option:not(:first):not(:last)').remove();
                    prompts.forEach(function(prompt, index) {
                        promptList.append(
                            $('<li>').text(prompt).append(
                                $('<span>').html(' &#128465;').addClass('delete-prompt').data('index', index)
                            )
                        );
                        promptSelect.append($('<option>', {
                            value: index,
                            text: prompt
                        }));
                    });
                }

                // Gestisce l'eliminazione di un prompt
                $(document).on('click', '.delete-prompt', function() {
                    var index = $(this).data('index');
                    prompts.splice(index, 1);
                    $('#prompt-select option[value="' + index + '"]').remove();
                    updatePromptList();
                    
                    $.ajax({
                        url: '<?php echo esc_url_raw(rest_url('simple-automator/v1/save-prompts')); ?>',
                        method: 'POST',
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader('X-WP-Nonce', '<?php echo wp_create_nonce('wp_rest'); ?>');
                        },
                        data: { prompts: prompts }
                    });
                });

                // Gestisce il click sul pulsante di anteprima
                $('#preview-button').click(function() {
                    var form = $('#simple-contact-form__form').serializeArray();
                    var selectedPromptIndex = $('#prompt-select').val();
                    if (selectedPromptIndex !== '' && selectedPromptIndex !== 'new') {
                        form.push({name: 'custom_prompt', value: prompts[selectedPromptIndex]});
                    }
                    
                    $('#loading-screen').show();
                    
                    $.ajax({
                        method: 'POST',
                        url: '<?php echo esc_url_raw(rest_url('simple-automator/v1/preview-draft')); ?>',
                        headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                        data: form,
                        success: function(response) {
                            $('#loading-screen').hide();
                            $('#preview-screen').show();
                            $('#preview-title').text(response.title);
                            $('#preview-image').attr('src', response.image_url);
                            $('#preview-content').val(response.content).css('height', 'auto').height(this.scrollHeight);
                            currentDraftId = response.draft_id;
                        },
                        error: function(xhr, status, error) {
                            $('#loading-screen').hide();
                            console.error('Errore:', xhr.responseText);
                            alert('Errore: ' + xhr.responseText);
                        }
                    });
                });

                // Gestisce il click sul pulsante per salvare la bozza
                $('#save-draft-button').click(function() {
                    var title = $('#preview-title').text();
                    var content = $('#preview-content').val();
                    var imageUrl = $('#preview-image').attr('src');
                    
                    // Verifica che tutti i campi necessari siano presenti
                    if (!title || !content || !imageUrl) {
                        alert('Errore: Titolo, contenuto e immagine sono obbligatori');
                        return;
                    }
                    
                    $('#loading-screen').show();
                    
                    // Invia una richiesta AJAX per salvare la bozza
                    $.ajax({
                        method: 'POST',
                        url: '<?php echo esc_url_raw(rest_url('simple-automator/v1/save-draft')); ?>',
                        headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                        data: {
                            title: title,
                            content: content,
                            image_url: imageUrl
                        },
                        success: function(response) {
                            $('#loading-screen').hide();
                            alert('Articolo aggiunto come bozza con successo!');
                        },
                        error: function(xhr, status, error) {
                            $('#loading-screen').hide();
                            console.error('Errore:', xhr.responseText);
                            alert('Errore nel salvataggio della bozza: ' + xhr.responseText);
                        }
                    });
                });

                // Gestisce il click sul pulsante per pubblicare l'articolo
                $('#publish-draft-button').click(function() {
                    var title = $('#preview-title').text();
                    var content = $('#preview-content').val();
                    var imageUrl = $('#preview-image').attr('src');
                    
                    // Verifica che tutti i campi necessari siano presenti
                    if (!title || !content || !imageUrl) {
                        alert('Errore: Titolo, contenuto e immagine sono obbligatori');
                        return;
                    }
                    
                    $('#loading-screen').show();
                    
                    // Invia una richiesta AJAX per pubblicare l'articolo
                    $.ajax({
                        method: 'POST',
                        url: '<?php echo esc_url_raw(rest_url('simple-automator/v1/publish-draft')); ?>',
                        headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                        data: {
                            title: title,
                            content: content,
                            image_url: imageUrl
                        },
                        success: function(response) {
                            $('#loading-screen').hide();
                            $('#preview-screen').hide();
                            $('#simple-contact-form__form')[0].reset();
                            alert('Articolo pubblicato con successo!');
                        },
                        error: function(xhr, status, error) {
                            $('#loading-screen').hide();
                            console.error('Errore:', xhr.responseText);
                            alert('Errore nel salvataggio della bozza: ' + xhr.responseText);
                        }
                    });
                });

                // Gestisce il click sul pulsante per chiudere l'anteprima
                $('#close-preview-button').click(function() {
                    $('#preview-screen').hide();
                });

                // Gestisce l'invio del form principale
                $('#simple-contact-form__form').on('submit', function(event) {
                    event.preventDefault();
                    var form = $(this).serializeArray();
                    var selectedPromptIndex = $('#prompt-select').val();
                    if (selectedPromptIndex !== '' && selectedPromptIndex !== 'new') {
                        form.push({name: 'custom_prompt', value: prompts[selectedPromptIndex]});
                    }
                    
                    $('#loading-screen').show();
                    
                    // Invia una richiesta AJAX per creare una bozza
                    $.ajax({
                        method: 'POST',
                        url: '<?php echo esc_url_raw(rest_url('simple-automator/v1/create-draft')); ?>',
                        headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                        data: form,
                        success: function(response) {
                            $('#loading-screen').hide();
                            alert('Articolo pubblicato con successo!');
                            $('#simple-contact-form__form')[0].reset();
                        },
                        error: function(xhr, status, error) {
                            $('#loading-screen').hide();
                            alert('Errore: ' + xhr.responseText);
                        }
                    });
                });
                
                // Aggiorna la lista dei prompt all'avvio
                updatePromptList();
            });
        </script>
        <?php
    }

    // Registra le rotte API REST
    public function register_rest_api() {
        register_rest_route(
            'simple-automator/v1',
            '/save-draft',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'handle_save_draft'),
                'permission_callback' => function() {
                    return current_user_can('edit_posts');
                }
            )
        );

        register_rest_route(
            'simple-automator/v1',
            '/save-settings',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'handle_save_settings'),
                'permission_callback' => function() {
                    return current_user_can('manage_options');
                }
            )
        );

        register_rest_route(
            'simple-automator/v1',
            '/save-prompts',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'handle_save_prompts'),
                'permission_callback' => function() {
                    return current_user_can('edit_posts');
                }
            )
        );

        register_rest_route(
            'simple-automator/v1',
            '/preview-draft',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'handle_preview_draft'),
                'permission_callback' => function() {
                    return current_user_can('edit_posts');
                }
            )
        );

        register_rest_route(
            'simple-automator/v1',
            '/publish-draft',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'handle_publish_draft'),
                'permission_callback' => function() {
                    return current_user_can('publish_posts');
                }
            )
        );
    }

    // Gestisce il salvataggio delle impostazioni via API
    public function handle_save_settings($request) {
        $params = $request->get_params();
        
        $this->api_key = sanitize_text_field($params['api_key']);
        $this->temperature = floatval($params['temperature']);
        $this->max_tokens = intval($params['max_tokens']);
        
        update_option('simple_automator_api_key', $this->api_key);
        update_option('simple_automator_temperature', $this->temperature);
        update_option('simple_automator_max_tokens', $this->max_tokens);
        
        return new WP_REST_Response('Impostazioni salvate con successo', 200);
    }

    // Gestisce il salvataggio dei prompt personalizzati via API
    public function handle_save_prompts($request) {
        $prompts = $request->get_param('prompts');
        $this->save_custom_prompts($prompts);
        return new WP_REST_Response('Prompts salvati con successo', 200);
    }

    // Gestisce il salvataggio di una bozza via API
    public function handle_save_draft($request) {
        $params = $request->get_params();
    
        if (empty($params['title']) || empty($params['content']) || empty($params['image_url'])) {
            return new WP_Error('missing_fields', 'Titolo, contenuto e URL dell\'immagine sono obbligatori', array('status' => 400));
        }
    
        $title = sanitize_text_field($params['title']);
        $content = wp_kses_post($params['content']);
        $image_url = esc_url_raw($params['image_url']);
    
        // Scarica l'immagine e ottieni l'ID dell'allegato
        $upload = media_sideload_image($image_url, 0, $title, 'id');
    
        if (is_wp_error($upload)) {
            return new WP_Error('image_upload_failed', 'Impossibile caricare l\'immagine: ' . $upload->get_error_message(), array('status' => 500));
        }
    
        $post_id = wp_insert_post([
            'post_type' => 'post',
            'post_title' => $title,
            'post_content' => $content,
            'post_status' => 'draft'
        ]);
    
        if (is_wp_error($post_id)) {
            return new WP_Error('insert_failed', 'Impossibile creare l\'articolo: ' . $post_id->get_error_message(), array('status' => 500));
        }
    
        set_post_thumbnail($post_id, $upload);
    
        return new WP_REST_Response('Articolo creato come bozza con successo', 200);
    }

    // Gestisce la generazione dell'anteprima di una bozza via API
    public function handle_preview_draft($request) {
        $params = $request->get_params();
        $custom_prompt = isset($params['custom_prompt']) ? $params['custom_prompt'] : '';
        $generated_content = $this->generate_content_with_chatgpt($params['titolo'], $params['descrizione'], $custom_prompt);
        $image_url = $this->generate_image_with_dalle($params['titolo']);
        
        return new WP_REST_Response([
            'title' => $params['titolo'],
            'content' => $generated_content,
            'image_url' => $image_url
        ], 200);
    }

    // Gestisce la pubblicazione di una bozza via API
    public function handle_publish_draft($request) {
        $params = $request->get_params();
    
        if (empty($params['title']) || empty($params['content']) || empty($params['image_url'])) {
            return new WP_Error('missing_fields', 'Titolo, contenuto e URL dell\'immagine sono obbligatori', array('status' => 400));
        }
    
        $title = sanitize_text_field($params['title']);
        $content = wp_kses_post($params['content']);
        $image_url = esc_url_raw($params['image_url']);
    
        // Scarica l'immagine e ottieni l'ID dell'allegato
        $upload = media_sideload_image($image_url, 0, $title, 'id');
    
        if (is_wp_error($upload)) {
            return new WP_Error('image_upload_failed', 'Impossibile caricare l\'immagine: ' . $upload->get_error_message(), array('status' => 500));
        }
    
        $post_id = wp_insert_post([
            'post_type' => 'post',
            'post_title' => $title,
            'post_content' => $content,
            'post_status' => 'publish'
        ]);
    
        if (is_wp_error($post_id)) {
            return new WP_Error('insert_failed', 'Impossibile creare l\'articolo: ' . $post_id->get_error_message(), array('status' => 500));
        }
    
        set_post_thumbnail($post_id, $upload);
    
        return new WP_REST_Response('Articolo pubblicato con successo', 200);
    }

    // Genera il contenuto dell'articolo utilizzando ChatGPT
    private function generate_content_with_chatgpt($title, $description, $custom_prompt = '') {
        $max_retries = 3;
        $retry_delay = 5;

        $prompt = "Scrivi un articolo di blog con il seguente titolo: '{$title}'. " .
                  "L'articolo dovrebbe essere basato su questa breve descrizione: '{$description}'. " .
                  "L'articolo dovrebbe essere lungo circa 500 parole, diviso in paragrafi e scritto in italiano. " .
                  $custom_prompt;

        for ($i = 0; $i < $max_retries; $i++) {
            $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
                'timeout' => 60,
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->api_key,
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode([
                    'model' => 'gpt-3.5-turbo',
                    'messages' => [
                        ['role' => 'system', 'content' => 'Sei un esperto scrittore di articoli di blog in italiano.'],
                        ['role' => 'user', 'content' => $prompt]
                    ],
                    'max_tokens' => $this->max_tokens,
                    'temperature' => $this->temperature,
                ]),
            ]);

            if (!is_wp_error($response)) {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($body['choices'][0]['message']['content'])) {
                    return $body['choices'][0]['message']['content'];
                }
            }

            if ($i < $max_retries - 1) {
                sleep($retry_delay);
            }
        }

        $error_message = is_wp_error($response) ? $response->get_error_message() : 'Risposta non valida dall\'API';
        error_log('Errore nella generazione del contenuto con ChatGPT dopo ' . $max_retries . ' tentativi: ' . $error_message);
        return new WP_Error('chatgpt_failed', 'Non è stato possibile generare il contenuto automaticamente dopo diversi tentativi.', array('status' => 500));
    }

    // Genera un'immagine utilizzando DALL-E
    private function generate_image_with_dalle($prompt) {
        $response = wp_remote_post('https://api.openai.com/v1/images/generations', [
            'timeout' => 40,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'prompt' => $prompt,
                'n' => 1,
                'size' => '1024x1024',
                'model' => 'dall-e-3',
                'quality' => 'hd'
            ]),
        ]);
    
        // Gestisce eventuali errori nella richiesta
        if (is_wp_error($response)) {
            return new WP_Error('dalle_error', 'Errore nella generazione dell\'immagine: ' . $response->get_error_message());
        }
    
        // Decodifica la risposta JSON
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['data'][0]['url'])) {
            return $body['data'][0]['url'];
        }
    
        // Restituisce un errore se non è possibile ottenere l'URL dell'immagine
        return new WP_Error('dalle_error', 'Errore nella risposta di DALL-E');
    }

    // Estrae un riassunto dal contenuto
    private function extract_summary($content, $max_length = 100) {
        // Rimuove tutti i tag HTML dal contenuto
        $plain_text = strip_tags($content);
        // Divide il testo in frasi
        $sentences = explode('.', $plain_text);
        // Prende le prime due frasi
        $summary = implode('.', array_slice($sentences, 0, 2));
        
        // Tronca il riassunto se supera la lunghezza massima
        if (strlen($summary) > $max_length) {
            $summary = substr($summary, 0, $max_length);
            $summary = substr($summary, 0, strrpos($summary, ' ')) . '...';
        }
        
        return trim($summary);
    }

    // Salva i prompt personalizzati per l'utente corrente
    private function save_custom_prompts($prompts) {
        $user_id = get_current_user_id();
        update_user_meta($user_id, 'simple_automator_custom_prompts', $prompts);
    }

    // Ottiene i prompt personalizzati dell'utente corrente
    private function get_custom_prompts() {
        $user_id = get_current_user_id();
        return get_user_meta($user_id, 'simple_automator_custom_prompts', true) ?: [];
    }
}

// Istanzia la classe SimpleAutomator
new SimpleAutomator();